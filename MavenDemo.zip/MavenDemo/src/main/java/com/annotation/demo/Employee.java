package com.annotation.demo;

public interface Employee {
abstract  public void doWork();
}
