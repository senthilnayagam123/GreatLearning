package com.beanlifecycle;

public interface Employee {
public void job();

}
