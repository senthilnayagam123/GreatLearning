package com.xml.demo;

public interface Employee {
	
abstract public void doWork();
	

}
