package com.dep.cons;

public interface Emp {
	public void doWork();
	public void jobDetails();

}
