package com.dep.cons;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
//import org.springframework.stereotype.Component;

@Configuration
@ComponentScan("com.dep.cons")
public class AppConfig {

}
