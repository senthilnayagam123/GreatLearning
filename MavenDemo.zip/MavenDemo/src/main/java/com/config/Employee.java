package com.config;

public interface Employee {
abstract public void doWork();
}
